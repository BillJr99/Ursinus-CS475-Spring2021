import java.net.Socket;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class ConnectionHandler extends Thread {
  private Socket conn;

  private DataInputStream input;
  private DataOutputStream output;

  public ConnectionHandler(Socket conn) {
    this.conn = conn;

    System.out.println("Connection established with client " + this.conn.getRemoteSocketAddress());

    try {
      this.input = new DataInputStream(this.conn.getInputStream());

      this.output = new DataOutputStream(this.conn.getOutputStream());      
    } catch(IOException e) {
      e.printStackTrace(System.err);
      System.exit(-1);
    }
  }

  public void run() {
    try {
      int request = this.input.readInt();

      System.out.println("Got: " + request);

      this.output.writeDouble(3.14);
    } catch(IOException e) {
      e.printStackTrace(System.err);
    }
  }
}