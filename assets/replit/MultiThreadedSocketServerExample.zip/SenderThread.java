import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Scanner;
import java.net.Socket;

public class SenderThread extends Thread {
  private DataOutputStream output;
  private Socket conn;
  private Scanner input;
  
  public SenderThread(Socket conn) {
    this.conn = conn;
    this.input = new Scanner(System.in);

    try {
      this.output = new DataOutputStream(this.conn.getOutputStream());
    } catch(IOException e) {
      e.printStackTrace(System.err);
    }
  }

  public void run() {
    while(true) {
      try {
        // Read from the keyboard a string
        // Write that string to output
        String msg = this.input.nextLine();
        this.output.writeUTF(msg);
      } catch(IOException e) {
        e.printStackTrace(System.err);
      }
    }
  }
}