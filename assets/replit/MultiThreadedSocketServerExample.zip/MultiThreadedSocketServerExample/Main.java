import java.net.Socket;
import java.net.ServerSocket;
import java.io.IOException;

class Main {
  private ServerSocket server;
  private int port;

  public Main(int port) {
    this.port = port;

    try {
      this.server = new ServerSocket(this.port);

      // Don't wait for a previously bound port to timeout
      this.server.setReuseAddress(true); 
    } catch(IOException e) {
      e.printStackTrace(System.err);
      System.exit(-1);
    }

    System.out.println("Server running on port " + this.port);
  }

  public void run() {
    while(true) {
      try {
        Socket conn = server.accept();

	System.out.println(conn);

        ConnectionHandler handler = new ConnectionHandler(conn);

        handler.start();
      } catch(IOException e) {
        e.printStackTrace(System.err);
      }
    }
  }

  public static void main(String[] args) {
    int port = 8082;

    Main app = new Main(port);
    app.run();
  }
}
