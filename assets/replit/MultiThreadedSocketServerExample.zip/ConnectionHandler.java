import java.net.Socket;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class ConnectionHandler extends Thread {
  private Socket conn;

  public ConnectionHandler(Socket conn) {
    this.conn = conn;

    System.out.println("Connection established with client " + this.conn.getRemoteSocketAddress());
  }

  public void run() {
    //Start receiver
    ReceiverThread receiver = new ReceiverThread(this.conn);
    receiver.start();

    //Start sender
    SenderThread sender = new SenderThread(this.conn);
    sender.start();    
  }
}