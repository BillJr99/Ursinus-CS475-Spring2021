import java.io.DataInputStream;
import java.net.Socket;
import java.io.IOException;

public class ReceiverThread extends Thread {
  private DataInputStream input;
  private Socket socket;

  public ReceiverThread(Socket conn) {
    this.conn = conn;

    try {
      this.input = new DataInputStream(this.conn.getInputStream());
    } catch(IOException e) {
      e.printStackTrace(System.err);
    }
  }

  public void run() {
    while(true) {
      try {
        // read a string from the socket (input)
        // print it to the screen
        double response = this.input.readDouble();

        System.out.println("Got: " + response);
      } catch(IOException e) {
        e.printStackTrace(System.err);
      }
    }    
  }
}
