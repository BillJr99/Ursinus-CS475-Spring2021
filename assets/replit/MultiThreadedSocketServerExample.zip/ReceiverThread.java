import java.io.DataInputStream;
import java.net.Socket;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ReceiverThread extends Thread {
  private DataInputStream input;
  private Socket conn;
  private BufferedReader br;

  public ReceiverThread(Socket conn) {
    this.conn = conn;
    this.br = new BufferedReader(new InputStreamReader(this.input));

    try {
      this.input = new DataInputStream(this.conn.getInputStream());
    } catch(IOException e) {
      e.printStackTrace(System.err);
    }
  }

  public void run() {
    while(true) {
      try {
        // read a string from the socket (input)
        // print it to the screen
        //double response = this.input.readDouble();
        String response = this.br.readLine();

        System.out.println("Got: " + response);
      } catch(IOException e) {
        e.printStackTrace(System.err);
      }
    }    
  }
}
