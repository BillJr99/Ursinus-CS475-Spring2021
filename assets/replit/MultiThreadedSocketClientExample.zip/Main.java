import java.net.Socket;
import java.io.IOException;

class Main {
  private int port;
  private String host;
  private Socket conn;

  public Main(String host, int port) {
    this.host = host;
    this.port = port;

    try {
      this.conn = new Socket(this.host, this.port);

    } catch(IOException e) {
      e.printStackTrace(System.err);
      System.exit(-1);
    }

    System.out.println("Connected to server " + this.conn.getRemoteSocketAddress() + " from " + this.conn.getLocalSocketAddress());
  }

  public void run() {
    //Start receiver
    ReceiverThread receiver = new ReceiverThread(this.conn);
    receiver.start();

    //Start sender
    SenderThread sender = new SenderThread(this.conn);
    sender.start();
  }

  public static void main(String[] args) {
    String host = "ThreadedSocketServerExample.billjr99.repl.co";
    int port = 8082;

    Main app = new Main(host, port);

    app.run();
  }
}