import java.io.DataInputStream;
import java.net.Socket;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ReceiverThread extends Thread {
  private DataInputStream input;
  private BufferedReader br;
  private Socket conn;

  public ReceiverThread(Socket conn) {
    this.conn = conn;

    try {
      this.input = new DataInputStream(this.conn.getInputStream());
      this.br = new BufferedReader(new InputStreamReader(this.input));
    } catch(IOException e) {
      e.printStackTrace(System.err);
    }
  }

  public void run() {
    while(true) {
      try {
        //int response = this.input.readInt();
        String response = this.br.readLine();
        System.out.println("Got: " + response);
      } catch(IOException e) {
        e.printStackTrace(System.err);
      }
    }    
  }
}
