import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Scanner;
import java.net.Socket;

public class SenderThread extends Thread {
  private DataOutputStream output;
  private Socket conn;
  private Scanner input;

  public SenderThread(Socket conn) {
    this.conn = conn;
    this.input = new Scanner(System.in);

    try {
      this.output = new DataOutputStream(this.conn.getOutputStream());
    } catch(IOException e) {
      e.printStackTrace(System.err);
    }
  }

  public void run() {
    while(true) {
      try {
        //this.output.writeDouble(3.14);
        String msg = this.input.nextLine();
        this.output.writeChars(msg + "\n");
      } catch(IOException e) {
        e.printStackTrace(System.err);
      }
    }
  }
}
