import java.net.Socket;
import java.io.IOException;
import java.io.DataInputStream;
import java.io.DataOutputStream;

class Main {
  private int port;
  private String host;
  private Socket conn;

  private DataInputStream input;
  private DataOutputStream output;

  public Main(String host, int port) {
    this.host = host;
    this.port = port;

    try {
      this.conn = new Socket(this.host, this.port);

      this.input = new DataInputStream(this.conn.getInputStream());

      this.output = new DataOutputStream(this.conn.getOutputStream());
    } catch(IOException e) {
      e.printStackTrace(System.err);
      System.exit(-1);
    }

    System.out.println("Connected to server " + this.conn.getRemoteSocketAddress() + " from " + this.conn.getLocalSocketAddress());
  }

  public void run() {
    try {
      this.output.writeInt(6);

      double response = this.input.readDouble();

      System.out.println("Got: " + response);
    } catch(IOException e) {
      e.printStackTrace(System.err);
    }
  }

  public static void main(String[] args) {
    String host = "ThreadedSocketServerExample.billjr99.repl.co";
    int port = 8082;

    Main app = new Main(host, port);

    app.run();
  }
}